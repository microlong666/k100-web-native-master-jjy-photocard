import Component from './iekkphotocard/index.js'
export default Component
